using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{
    // Start is called before the first frame update
    // var remains: GameObject;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // if(Input.GetKey(Keycode.space))
        // {
        //     Instantiate(remains, transform.position, transform.rotation);
        //     Destroy(gameObject);
        // }
    }
}
